<?php

/**
 * The REST API functionality of the plugin.
 *
 * @link       https://arkod.fr
 * @since      1.0.0
 *
 * @package    Arkod_WP
 * @subpackage Arkod_WP/api
 */

/**
 * The REST API functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the REST API stylesheet and JavaScript.
 *
 * @package    Arkod_WP
 * @subpackage Arkod_WP/api
 * @author     ARKOD <dev@arkod.fr>
 */
class Arkod_WP_Api {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $arkod_wp    The ID of this plugin.
	 */
	private $arkod_wp;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $arkod_wp       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $arkod_wp, $version ) {

		$this->arkod_wp = $arkod_wp;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function register_post_oxygen_design_set_config_route() {

		register_rest_route( 'arkod-wp/v1', '/oxygen/design-set', array(
			'methods' => 'POST',
			'callback' => array( $this, 'configure_oxygen_design_set' ),
		) );

	}

	/**
	 * Configure Oxygen's design set.
	 *
	 * @since    1.0.0
	 */
	public function configure_oxygen_design_set( WP_REST_Request $request ) {
		$design_set_key = $request->get_param( 'design-set' );

		$oxygen_plugin_active = in_array( 'oxygen/functions.php', (array) get_option( 'active_plugins', array() ), true );
		if ( !$oxygen_plugin_active ) {
			return new WP_Error( 'no-oxygen', 'Oxygen not installed and actived.', array( 'status' => 404 ) );
		}

		// Set up Oxygen
		update_option( 'oxygen_vsb_enable_signature_validation', "true" );
		delete_transient('oxygen-vsb-just-activated');
		add_option('oxygen-vsb-activated', true);

		// Enable 3rd Party Design Sets
		// Yes : option oxygen_vsb_enable_3rdp_designsets = "true"
		// No : option oxygen_vsb_enable_3rdp_designsets = ""
		$design_sets_disabled = empty( get_option( 'oxygen_vsb_enable_3rdp_designsets' ) );
		if ( $design_sets_disabled ) {
			update_option( 'oxygen_vsb_enable_3rdp_designsets', "true" );
		}

		// Add given design set
		if ( !is_null( $design_set_key ) ) {
			$design_set_configration_result = $this->add_design_set( $design_set_key );
			if ( is_object( $design_set_configration_result) ) {
				return $design_set_configration_result;
			} else {
				return 'Design configured.';
			}
		}
		
	}
	
	/**
	 * Add a design set to Oxygen.
	 * 
	 * NOTE : This function is copy/pasted (with a bit of adaptation for error management)
	 * from the function oxygen_vsb_process_source_site() available in
	 * oxygen/component-framework/admin/pages.php:322
	 *
	 * @since    1.0.0
	 */
	private function add_design_set($key) {
		$source_key = base64_decode( $key );
		$exploded = explode( "\n", $source_key );
		$valid = true;
		$source_site_label = isset( $exploded[1]) ? $exploded[1] : false;
		$source_site_url = isset( $exploded[0]) ? $exploded[0] : false;
		$source_site_access = isset( $exploded[2]) ? $exploded[2] : false;

		$valid = $valid && $source_site_label && $source_site_url;

		if ( !$valid ) {
			return new WP_Error( 'invalid-design-set-key', 'Invalid design set key', array( 'status' => 400 ) );
		}

		if ( $valid && sizeof( $oxygen_vsb_source_sites ) > 0 ) {
			// check if source site label or url already exists.
			if( isset( $oxygen_vsb_source_sites[ sanitize_title( $source_site_label ) ] ) ) {
				$valid = false;
				return new WP_Error( 'existing-design-set', 'A design set with the same title already exists', array( 'status' => 400 ) );
			}
			
			// check if sourcesite url already exists
			if ( array_search( $source_site_url, $oxygen_vsb_source_sites ) ) {
				$valid = false;
				return new WP_Error( 'existing-design-set', 'A design set with the same URL already exists', array( 'status' => 400 ) );
			}
		}

		if($valid) {
			// attempt to connect to the source site and check if the access is valid
			$url = $source_site_url.'/wp-json/oxygen-vsb-connection/v1/addrequest/';
			$args = array(
			  'headers' => array(
			    'oxygenclientversion' => '3.7rc1',
			    'auth' => md5($source_site_access)
			  ),
			  'timeout' => 15,
			);

			$result = wp_remote_request( $url, $args );
			$status = wp_remote_retrieve_response_code( $result );
			if ( is_wp_error( $result ) ) {
				return new WP_Error( 'design-set-unavailable', $result->get_error_message(), array( 'status' => $status ) );
			} 
			elseif( $status !== 200 ) {
				return new WP_Error( 'design-set-unavailable', wp_remote_retrieve_response_message($result), array( 'status' => $status ) );
			} 
			else {
				$result = json_decode( $result['body'], true );
				if( is_array( $result ) && isset( $result['access'] ) && intval( $result['access'] ) === 1 ) {
					$oxygen_vsb_source_sites[ sanitize_title( $source_site_label ) ] = array( 'label' => sanitize_text_field( $source_site_label ), 'url' => sanitize_url( $source_site_url ), 'accesskey' => ( $source_site_access === false ? '' : sanitize_text_field( $source_site_access ) ) );
					update_option( 'oxygen_vsb_source_sites', $oxygen_vsb_source_sites );
					return true;
				}
				else {
					return new WP_Error( 'design-set-access-denied', 'Access to the design set denied', array( 'status' => 503 ) );
				}
			}
		}
	}

}
