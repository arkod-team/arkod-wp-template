<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://arkod.fr
 * @since      1.0.0
 *
 * @package    Arkod_WP
 * @subpackage Arkod_WP/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Arkod_WP
 * @subpackage Arkod_WP/includes
 * @author     ARKOD <dev@arkod.fr>
 */
class Arkod_WP_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
