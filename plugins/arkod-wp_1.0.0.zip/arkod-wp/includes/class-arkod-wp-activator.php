<?php

/**
 * Fired during plugin activation
 *
 * @link       https://arkod.fr
 * @since      1.0.0
 *
 * @package    Arkod_WP
 * @subpackage Arkod_WP/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Arkod_WP
 * @subpackage Arkod_WP/includes
 * @author     ARKOD <dev@arkod.fr>
 */
class Arkod_WP_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
